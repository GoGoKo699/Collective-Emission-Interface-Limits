const fs=require('fs'),path=require('path');
const mj='/workspace/scratch/6c812e382056/math-preview/node_modules/mathjax-full/js';
const {mathjax}=require(mj+'/mathjax.js');
const {TeX}=require(mj+'/input/tex.js');
const {SVG}=require(mj+'/output/svg.js');
const {liteAdaptor}=require(mj+'/adaptors/liteAdaptor.js');
const {RegisterHTMLHandler}=require(mj+'/handlers/html.js');
const {AllPackages}=require(mj+'/input/tex/AllPackages.js');
const adaptor=liteAdaptor();RegisterHTMLHandler(adaptor);
const tex=new TeX({packages:AllPackages.filter(x=>!['noerrors','noundefined','autoload','require'].includes(x)),formatError:(jax,error)=>{throw error;}});
const doc=mathjax.document('',{InputJax:tex,OutputJax:new SVG({fontCache:'none'})});
const rows=JSON.parse(fs.readFileSync(__dirname+'/formulas.json','utf8'));
const renders=[],errors=[];
for(const row of rows){
 try{
  const node=doc.convert(row.tex,{display:row.display,em:16,ex:8,containerWidth:850});
  const html=adaptor.outerHTML(node);
  if(html.includes('data-mjx-error'))throw Error('MathJax error node');
  renders.push({...row,html});
 }catch(e){errors.push({...row,error:e.message});}
}
fs.writeFileSync(__dirname+'/rendered.json',JSON.stringify(renders));
fs.writeFileSync(__dirname+'/compile-report.json',JSON.stringify({expressions:rows.length,compiled:renders.length,errors},null,2));
console.log(JSON.stringify({expressions:rows.length,compiled:renders.length,errors}));
if(errors.length)process.exit(1);
