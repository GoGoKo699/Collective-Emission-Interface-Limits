const fs=require('fs'),path=require('path');
const {marked}=require(path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES,'marked'));
const {chromium}=require(path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES,'playwright'));
const renders=JSON.parse(fs.readFileSync(__dirname+'/rendered.json','utf8'));
const expressions=new Map(renders.map(x=>[(x.display?'display:':'inline:')+x.tex.trim(),x.html]));
function math(source,display){const value=expressions.get((display?'display:':'inline:')+source.trim());if(!value)throw Error('Missing render: '+source);return display?'<div class="math-display">'+value+'</div>':value;}
marked.use({gfm:true,extensions:[
 {name:'mathBlock',level:'block',start:src=>src.indexOf('$$'),tokenizer(src){const m=/^\$\$([\s\S]*?)\$\$(?:\n|$)/.exec(src);if(m)return{type:'mathBlock',raw:m[0],text:m[1]};},renderer:t=>math(t.text,true)},
 {name:'mathInline',level:'inline',start:src=>src.indexOf('$'),tokenizer(src){const m=/^\$`([^`]+)`\$/.exec(src)||/^\$([^$\n]+)\$/.exec(src);if(m)return{type:'mathInline',raw:m[0],text:m[1]};},renderer:t=>math(t.text,false)}
 ],renderer:{code(t){if(t.lang==='math')return math(t.text,true);return false;}}});
const style='body{margin:0;color:#1f2328;background:#fff;font:16px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}.markdown-body{max-width:900px;margin:24px auto;padding:32px;border:1px solid #d1d9e0;border-radius:6px}h1{font-size:32px}h2{font-size:24px}h1,h2{border-bottom:1px solid #d1d9e0;padding-bottom:.3em;line-height:1.25}h3{font-size:20px}a{color:#0969da;text-decoration:none}p{margin:16px 0}table{border-collapse:collapse;display:block;max-width:100%;overflow-x:auto;margin:16px 0}th,td{border:1px solid #d1d9e0;padding:6px 13px}tr:nth-child(even){background:#f6f8fa}pre{background:#f6f8fa;padding:16px;overflow:auto;border-radius:6px}code{font:85% ui-monospace,SFMono-Regular,Consolas,monospace}.math-display{overflow-x:auto;overflow-y:hidden;margin:16px 0;padding:4px 0;text-align:center}mjx-container[jax="SVG"]{direction:ltr}mjx-container[jax="SVG"]>svg{overflow:visible;min-height:1px;min-width:1px}mjx-container[jax="SVG"][display="true"]{display:block;text-align:center;margin:0}@media(max-width:600px){.markdown-body{margin:0;padding:20px;border:none}h1{font-size:28px}}';
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:'/workspace/scratch/9781207fd51b/style-preview/chrome/chrome-headless-shell-linux64/chrome-headless-shell',args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:1280,height:1300},deviceScaleFactor:1});
 const reports=[];
 for(const [file,name,sections] of [['research/PHYSICAL_SCOPE.md','physical',['B. The leading mismatch','C. Scalar source','A. What the receiver']],['research/THEOREM.md','theorem',['2. Reduction of the channel objective']]]){
  const md=fs.readFileSync('/workspace/scratch/140f88f602fc/Collective-Emission-Interface-Limits/'+file,'utf8');
  const html='<!doctype html><meta charset="utf-8"><style>'+style+'</style><article class="markdown-body">'+marked.parse(md)+'</article>';
  fs.writeFileSync(__dirname+'/'+name+'.html',html);await page.setContent(html);
  for(const [width,height,label] of [[1280,1300,'desktop'],[390,844,'mobile']]){
   await page.setViewportSize({width,height});
   reports.push({file,label,...await page.evaluate(()=>({math:document.querySelectorAll('mjx-container').length,rawMath:document.body.innerText.includes('$'),overflow:document.documentElement.scrollWidth>innerWidth,scrollWidth:document.documentElement.scrollWidth,viewport:innerWidth,wideElements:Array.from(document.querySelectorAll('mjx-container,a')).filter(e=>!e.closest('.math-display')&&e.getBoundingClientRect().right>innerWidth).map(e=>({tag:e.tagName,text:e.outerHTML.slice(0,140),right:e.getBoundingClientRect().right,width:e.getBoundingClientRect().width}))}))});
   for(let i=0;i<sections.length;i++){
    const h=page.locator('h2').filter({hasText:sections[i]}).first();
    await h.evaluate(e=>e.scrollIntoView({block:'start'}));
   await page.screenshot({path:__dirname+'/'+name+'-'+label+'-'+i+'.png'});
   }
   if(name==='theorem'){
    await page.locator('p').filter({hasText:'For a nonnegative receiving waveform with attenuation'}).evaluate(e=>e.scrollIntoView({block:'start'}));
    await page.screenshot({path:__dirname+'/'+name+'-'+label+'-attenuation.png'});
   }
  }
 }
 fs.writeFileSync(__dirname+'/visual-report.json',JSON.stringify(reports,null,2));
 console.log(JSON.stringify(reports,null,2));await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
