from pathlib import Path
import json
import mpmath as mp
mp.mp.dps=60
cases=[(2,2),(3,2),(3,3),(12,4),(30,8),(60,12)]
rows=[]
for N,m in cases:
    a=mp.mpf(m-1)/N;b=1-a
    def integrand(s):
        if s == 0: return mp.mpf(0)
        val=mp.mpf(0)
        for k in range(1,m+1):
            prob=mp.binomial(m,k)*s**k*(1-s)**(m-k)
            x=k*(1-a*s);y=k*(1-mp.mpf(k-1)/N)
            val += prob*(x*mp.log(x/y)-x+y)
        return val/(s*(1-a*s))
    path=mp.quad(integrand,[0,mp.mpf('.5'),1])
    closed=m*(-b/a*mp.log(b)-1)-sum(mp.log(1-mp.mpf(j)/N) for j in range(m))
    bound=mp.mpf(m*(m-1))/(12*N*N*b*b)
    assert abs(path-closed)<mp.mpf('1e-50')
    assert 0<=closed<=bound
    row=dict(N=N,m=m,path_integral_entropy=str(path),closed_form_entropy=str(closed),absolute_discrepancy=str(abs(path-closed)),uniform_upper_bound=str(bound))
    rows.append(row)
    print(f'N={N} m={m}: abs entropy discrepancy={mp.nstr(abs(path-closed),4)}; D={mp.nstr(closed,13)}; B={mp.nstr(bound,13)}')
out=Path('/workspace/scratch/140f88f602fc/independent_path_entropy_check_2026-10-05.json')
out.write_text(json.dumps(dict(status='PASS',case_count=len(rows),precision_decimal_digits=mp.mp.dps,tolerance='1e-50',method='Direct one-dimensional counting-process relative-entropy integral under binomial product reference; no repository scientific module imported.',scope='Additional internal agent diagnostic, not external independent review or a universal proof.',results=rows),indent=2)+'\n')
print(f'PASS; wrote {out}')
